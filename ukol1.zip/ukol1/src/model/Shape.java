package model;

/**
 * Bázová třída pro geometrické objekty.
 */
public abstract class Shape {
    // Bázová třída pro všechny geometrické objekty
    // Může obsahovat společné metody a vlastnosti
}

